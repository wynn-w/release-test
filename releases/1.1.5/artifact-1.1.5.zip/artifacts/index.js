'use strict';

console.log('ready')(() => {
  console.log('next level');
});
console.log('finish');
